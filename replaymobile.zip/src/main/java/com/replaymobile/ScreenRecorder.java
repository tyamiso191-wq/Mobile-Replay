package com.replaymobile;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.ScreenshotRecorder;
import org.lwjgl.stb.STBIWriteCallback;
import org.lwjgl.stb.STBImageWrite;
import org.lwjgl.system.MemoryUtil;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Oyunun kendi cizim tamponunu (menuler, sandiklar, ESC dahil) videoya kaydeder.
 * Android'in ekran katmanini (launcher tuslari vb.) kaydetmez. Cikti: AVI (MJPEG), en fazla 1080p.
 */
public final class ScreenRecorder {
    private record Frame(ByteBuffer buf, int w, int h) {}

    private static volatile boolean recording = false;
    private static ArrayBlockingQueue<Frame> queue;
    private static Thread worker;
    private static volatile long firstNs;
    private static volatile long lastNs;

    private static boolean shotResolved = false;
    private static Method shot;
    private static boolean shotAsync;

    public static boolean isRecording() {
        return recording;
    }

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("screen_recordings");
    }

    public static void toggle() {
        if (recording) stop();
        else start();
    }

    public static synchronized void start() {
        if (recording || (worker != null && worker.isAlive())) return;
        try {
            Files.createDirectories(dir());
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            Path out = dir().resolve(stamp + ".avi");
            queue = new ArrayBlockingQueue<>(3);
            firstNs = 0;
            lastNs = 0;
            recording = true;
            worker = new Thread(() -> work(out), "replaymobile-screenrec");
            worker.setDaemon(true);
            worker.start();
            ReplayMobileClient.LOG.info("Ekran kaydi basladi: {}", out);
        } catch (Throwable t) {
            recording = false;
            ReplayMobileClient.LOG.error("Ekran kaydi baslatilamadi", t);
        }
    }

    public static synchronized void stop() {
        recording = false;
        if (worker != null) {
            try {
                worker.join(20000);
            } catch (InterruptedException ignored) {
            }
            worker = null;
        }
    }

    /** Her oyun tikinde cagrilir (20 kare/sn). */
    public static void onTick(MinecraftClient mc) {
        if (!recording) return;
        try {
            if (!shotResolved) resolve();
            if (shot == null) {
                ReplayMobileClient.LOG.error("Ekran goruntusu yontemi bulunamadi");
                recording = false;
                return;
            }
            Framebuffer fb = mc.getFramebuffer();
            if (shotAsync) {
                Consumer<NativeImage> cb = ScreenRecorder::handleImage;
                shot.invoke(null, fb, cb);
            } else {
                Object img = shot.invoke(null, fb);
                if (img instanceof NativeImage ni) handleImage(ni);
            }
        } catch (Throwable t) {
            ReplayMobileClient.LOG.error("Kare yakalanamadi", t);
            recording = false;
        }
    }

    private static void resolve() {
        shotResolved = true;
        for (Method m : ScreenshotRecorder.class.getDeclaredMethods()) {
            if (!Modifier.isStatic(m.getModifiers())) continue;
            Class<?>[] pt = m.getParameterTypes();
            if (pt.length >= 1 && pt[0] == Framebuffer.class) {
                if (pt.length == 1 && m.getReturnType() == NativeImage.class) {
                    shot = m;
                    shotAsync = false;
                    m.setAccessible(true);
                    return;
                }
                if (pt.length == 2 && pt[1] == Consumer.class) {
                    shot = m;
                    shotAsync = true;
                    m.setAccessible(true);
                    return;
                }
            }
        }
    }

    private static void handleImage(NativeImage img) {
        try {
            if (!recording) return;
            int w = img.getWidth();
            int h = img.getHeight();
            if (w < 2 || h < 2) return;
            long ptr = pixelPointer(img, w, h);
            if (ptr == 0) {
                ReplayMobileClient.LOG.error("Piksel bellegi bulunamadi");
                recording = false;
                return;
            }
            long bytes = (long) w * h * 4;
            ByteBuffer copy = MemoryUtil.memAlloc((int) bytes);
            MemoryUtil.memCopy(ptr, MemoryUtil.memAddress(copy), bytes);
            if (!queue.offer(new Frame(copy, w, h))) {
                MemoryUtil.memFree(copy);
                return;
            }
            long now = System.nanoTime();
            if (firstNs == 0) firstNs = now;
            lastNs = now;
        } catch (Throwable t) {
            ReplayMobileClient.LOG.error("Kare kopyalanamadi", t);
        } finally {
            img.close();
        }
    }

    private static long pixelPointer(NativeImage img, int w, int h) throws Exception {
        long expected = (long) w * h * 4;
        for (Field f : NativeImage.class.getDeclaredFields()) {
            if (f.getType() == long.class && !Modifier.isStatic(f.getModifiers())) {
                f.setAccessible(true);
                long v = f.getLong(img);
                if (v != 0 && v != expected) return v;
            }
        }
        return 0;
    }

    private static void work(Path out) {
        AviWriter avi = null;
        int tw = 0;
        int th = 0;
        int written = 0;
        final ByteArrayOutputStream baos = new ByteArrayOutputStream(1 << 18);
        STBIWriteCallback cb = STBIWriteCallback.create((ctx, data, size) -> {
            ByteBuffer b = MemoryUtil.memByteBuffer(data, size);
            byte[] tmp = new byte[size];
            b.get(tmp);
            baos.write(tmp, 0, size);
        });
        try {
            while (true) {
                Frame f = queue.poll(200, TimeUnit.MILLISECONDS);
                if (f == null) {
                    if (!recording && queue.isEmpty()) break;
                    continue;
                }
                ByteBuffer enc = null;
                try {
                    if (avi == null) {
                        th = Math.min(1080, f.h());
                        tw = (int) Math.round(f.w() * (double) th / f.h());
                        tw &= ~1;
                        th &= ~1;
                        avi = new AviWriter(out, tw, th);
                    }
                    int comp;
                    if (f.w() == tw && f.h() == th) {
                        enc = f.buf();
                        comp = 4;
                    } else {
                        enc = MemoryUtil.memAlloc(tw * th * 3);
                        scale(f.buf(), f.w(), f.h(), enc, tw, th);
                        comp = 3;
                    }
                    baos.reset();
                    STBImageWrite.stbi_write_jpg_to_func(cb, 0L, tw, th, comp, enc, 90);
                    byte[] jpeg = baos.toByteArray();
                    avi.addFrame(jpeg, jpeg.length);
                    written++;
                    if (avi.length() > 1_900_000_000L) {
                        ReplayMobileClient.LOG.warn("Dosya boyutu siniri doldu, kayit durduruluyor");
                        recording = false;
                    }
                } finally {
                    if (enc != null && enc != f.buf()) MemoryUtil.memFree(enc);
                    MemoryUtil.memFree(f.buf());
                }
            }
        } catch (Throwable t) {
            recording = false;
            ReplayMobileClient.LOG.error("Ekran kaydi hatasi", t);
        } finally {
            cb.free();
            Frame rest;
            while (queue != null && (rest = queue.poll()) != null) MemoryUtil.memFree(rest.buf());
            if (avi != null) {
                try {
                    double secs = (lastNs - firstNs) / 1e9;
                    double fps = (written > 1 && secs > 0.1) ? (written - 1) / secs : 20.0;
                    fps = Math.max(1.0, Math.min(60.0, fps));
                    avi.close(fps);
                    ReplayMobileClient.LOG.info("Ekran kaydi bitti: {} ({} kare)", out, written);
                } catch (Throwable t) {
                    ReplayMobileClient.LOG.error("AVI kapatilamadi", t);
                }
            }
        }
    }

    /** En yakin komsu ile RGBA -> RGB olcekleme. */
    private static void scale(ByteBuffer src, int w, int h, ByteBuffer dst, int tw, int th) {
        for (int y = 0; y < th; y++) {
            int sy = (int) ((long) y * h / th);
            for (int x = 0; x < tw; x++) {
                int sx = (int) ((long) x * w / tw);
                int si = (sy * w + sx) * 4;
                int di = (y * tw + x) * 3;
                dst.put(di, src.get(si));
                dst.put(di + 1, src.get(si + 1));
                dst.put(di + 2, src.get(si + 2));
            }
        }
    }

    private ScreenRecorder() {}
}
