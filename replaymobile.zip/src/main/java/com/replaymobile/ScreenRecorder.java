package com.replaymobile;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.ScreenshotRecorder;
import org.lwjgl.stb.STBIWriteCallback;
import org.lwjgl.stb.STBImageWrite;
import org.lwjgl.system.MemoryUtil;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Oyunun kendi cizim tamponunu (menuler, sandiklar, ESC dahil) videoya kaydeder; oyun sesi ve
 * mikrofon da eklenir. Android'in ekran katmanini (launcher tuslari vb.) kaydetmez.
 *
 * Performans: ekran goruntusu okuma maliyeti olculur ve oyunun akiciligini korumak icin yakalama
 * hizi kendiliginden ayarlanir (cozunurluk dusurulmez). JPEG kodlama birden cok is parcacigina
 * dagitilir. Video sabit kare hizinda yazilir, eksik kareler tekrarlanir (ses ile senkron kalir).
 */
public final class ScreenRecorder {
    private static final int QUALITY = 75;
    private static final double[] BUDGET_MS_PER_SEC = {120.0, 220.0, 400.0};
    private static final Consumer<NativeImage> CALLBACK = ScreenRecorder::handleImage;

    private record Frame(ByteBuffer buf, int w, int h, long ns) {}

    private record Pending(Future<byte[]> future, int copies) {}

    private static final class Scratch {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream(1 << 18);
        final STBIWriteCallback cb = STBIWriteCallback.create((ctx, data, size) -> {
            ByteBuffer b = MemoryUtil.memByteBuffer(data, size);
            byte[] tmp = new byte[size];
            b.get(tmp);
            baos.write(tmp, 0, size);
        });
        ByteBuffer scaled;
    }

    private static volatile boolean recording = false;
    private static ArrayBlockingQueue<Frame> queue;
    private static final ArrayBlockingQueue<ByteBuffer> pool = new ArrayBlockingQueue<>(6);
    private static Thread worker;
    private static volatile long firstNs;

    private static int captureFps = 20;
    private static int targetHeight = 1080;
    private static double budget = 220.0;
    private static double tickAcc = 0;

    // olculen maliyet (ms), ustel ortalama
    private static volatile double emaInvokeMs = 8.0;
    private static volatile double emaCbMs = 8.0;
    private static volatile long cbAccumNs = 0;

    private static final java.util.concurrent.ConcurrentHashMap<String, Integer> dbgCount =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** Her asama icin ilk 2 olayi gunluge yazar; cokme olursa son satir yeri gosterir. */
    static void dbg(String key, String msg) {
        int n = dbgCount.merge(key, 1, Integer::sum);
        if (n <= 2) ReplayMobileClient.LOG.info("[ekran-kaydi] {}", msg);
    }

    // oyun FPS geri beslemesi
    private static final double[] RATIO = {0.85, 0.70, 0.50};
    private static final int[] fpsRing = new int[20];
    private static int fpsRingN = 0;
    private static long lastSampleNs = 0;
    private static double fpsBase = 0;
    private static double baseAtStart = 0;
    private static double effCap = 8.0;
    private static long lastCtlNs = 0;
    private static long lastStatNs = 0;

    private static boolean shotResolved = false;
    private static Method shot;
    private static boolean shotAsync;

    public static boolean isRecording() {
        return recording;
    }

    public static long firstNs() {
        return firstNs;
    }

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("screen_recordings");
    }

    public static void toggle() {
        if (recording) stop();
        else start();
    }

    public static synchronized void start() {
        if (recording || (worker != null && worker.isAlive())) return;
        try {
            Files.createDirectories(dir());
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            Path out = dir().resolve(stamp + ".avi");
            captureFps = Math.max(5, Math.min(20, Config.recordFps));
            targetHeight = Math.max(240, Math.min(1080, Config.recordHeight));
            budget = BUDGET_MS_PER_SEC[Math.max(0, Math.min(2, Config.perfMode))];
            tickAcc = 0;
            baseAtStart = fpsBase;
            effCap = Math.min(captureFps, 8.0);
            lastCtlNs = System.nanoTime();
            lastStatNs = lastCtlNs;
            queue = new ArrayBlockingQueue<>(2);
            firstNs = 0;
            GameAudio.begin();
            final boolean audio = GameAudio.isRunning();
            recording = true;
            worker = new Thread(() -> work(out, audio), "replaymobile-screenrec");
            worker.setDaemon(true);
            worker.setPriority(Thread.MIN_PRIORITY);
            worker.start();
            ReplayMobileClient.LOG.info("Ekran kaydi basladi: {} ({}p, en cok {} kare/sn, ses: {})",
                    out, targetHeight, captureFps, audio);
        } catch (Throwable t) {
            recording = false;
            GameAudio.finish();
            ReplayMobileClient.LOG.error("Ekran kaydi baslatilamadi", t);
        }
    }

    public static synchronized void stop() {
        recording = false;
        if (worker != null) {
            try {
                worker.join(60000);
            } catch (InterruptedException ignored) {
            }
            worker = null;
        }
    }

    /** Her oyun tikinde (20/sn) cagrilir; yakalama hizi olculen maliyete gore ayarlanir. */
    public static void onTick(MinecraftClient mc) {
        if (!recording) {
            sampleFps(mc);
            return;
        }
        try {
            controlByFps(mc);
            double cost = Math.max(1.0, emaInvokeMs + emaCbMs);
            double eff = Math.max(2.0, Math.min(effCap, Math.min((double) captureFps, budget / cost)));
            tickAcc += eff;
            if (tickAcc < 20.0) return;
            tickAcc -= 20.0;
            if (queue.remainingCapacity() == 0) return;

            if (!shotResolved) resolve();
            if (shot == null) {
                ReplayMobileClient.LOG.error("Ekran goruntusu yontemi bulunamadi");
                recording = false;
                return;
            }
            Framebuffer fb = mc.getFramebuffer();
            dbg("req", "kare istegi gonderiliyor (" + (shotAsync ? "async" : "sync") + ")");
            cbAccumNs = 0;
            long t = System.nanoTime();
            if (shotAsync) {
                shot.invoke(null, fb, CALLBACK);
            } else {
                Object img = shot.invoke(null, fb);
                if (img instanceof NativeImage ni) handleImage(ni);
            }
            double total = (System.nanoTime() - t) / 1e6;
            double only = Math.max(0.0, total - cbAccumNs / 1e6);
            emaInvokeMs = emaInvokeMs * 0.8 + only * 0.2;
        } catch (Throwable t) {
            ReplayMobileClient.LOG.error("Kare yakalanamadi", t);
            recording = false;
        }
    }

    /** Kayit disindayken oyunun normal FPS'ini ogrenir (son ~20 saniyenin en yuksegi). */
    private static void sampleFps(MinecraftClient mc) {
        long now = System.nanoTime();
        if (now - lastSampleNs < 1_000_000_000L) return;
        lastSampleNs = now;
        if (mc.world == null || mc.currentScreen != null) return;
        int f = mc.getCurrentFps();
        if (f <= 0) return;
        fpsRing[fpsRingN % fpsRing.length] = f;
        fpsRingN++;
        int n = Math.min(fpsRingN, fpsRing.length);
        int max = 0;
        for (int i = 0; i < n; i++) max = Math.max(max, fpsRing[i]);
        fpsBase = max;
    }

    /** Oyunun FPS'i tabanin altina duserse yakalama hizini kisar, rahatlarsa artirir. */
    private static void controlByFps(MinecraftClient mc) {
        long now = System.nanoTime();
        if (now - lastCtlNs < 1_000_000_000L) return;
        lastCtlNs = now;
        int fps = mc.getCurrentFps();
        if (baseAtStart > 0 && fps > 0) {
            double floor = baseAtStart * RATIO[Math.max(0, Math.min(2, Config.perfMode))];
            if (fps < floor) effCap = Math.max(2.0, effCap * 0.75);
            else if (fps > floor * 1.1) effCap = Math.min(captureFps, effCap * 1.1 + 0.3);
        }
        if (now - lastStatNs > 5_000_000_000L) {
            lastStatNs = now;
            ReplayMobileClient.LOG.info("[ekran-kaydi] oyun FPS={} taban={} yakalama siniri={}/sn maliyet={}ms",
                    fps, (int) baseAtStart, String.format("%.1f", effCap),
                    String.format("%.1f", emaInvokeMs + emaCbMs));
        }
    }

    private static void resolve() {
        shotResolved = true;
        for (Method m : ScreenshotRecorder.class.getDeclaredMethods()) {
            if (!Modifier.isStatic(m.getModifiers())) continue;
            Class<?>[] pt = m.getParameterTypes();
            if (pt.length >= 1 && pt[0] == Framebuffer.class) {
                if (pt.length == 1 && m.getReturnType() == NativeImage.class) {
                    shot = m;
                    shotAsync = false;
                    m.setAccessible(true);
                    return;
                }
                if (pt.length == 2 && pt[1] == Consumer.class) {
                    shot = m;
                    shotAsync = true;
                    m.setAccessible(true);
                    return;
                }
            }
        }
    }

    private static ByteBuffer takeBuffer(int size) {
        ByteBuffer b = pool.poll();
        if (b != null && b.capacity() != size) {
            MemoryUtil.memFree(b);
            b = null;
        }
        return b != null ? b : MemoryUtil.memAlloc(size);
    }

    private static void giveBuffer(ByteBuffer b) {
        if (!pool.offer(b)) MemoryUtil.memFree(b);
    }

    private static void handleImage(NativeImage img) {
        long t = System.nanoTime();
        try {
            if (!recording) return;
            int w = img.getWidth();
            int h = img.getHeight();
            if (w < 2 || h < 2) return;
            dbg("img", "goruntu alindi " + w + "x" + h);
            long ptr = pixelPointer(img, w, h);
            dbg("ptr", "piksel adresi bulundu: " + (ptr != 0));
            if (ptr == 0) {
                ReplayMobileClient.LOG.error("Piksel bellegi bulunamadi");
                recording = false;
                return;
            }
            long bytes = (long) w * h * 4;
            ByteBuffer copy = takeBuffer((int) bytes);
            MemoryUtil.memCopy(ptr, MemoryUtil.memAddress(copy), bytes);
            dbg("copy", "kare kopyalandi");
            long now = System.nanoTime();
            if (!queue.offer(new Frame(copy, w, h, now))) {
                giveBuffer(copy);
                return;
            }
            if (firstNs == 0) firstNs = now;
        } catch (Throwable e) {
            ReplayMobileClient.LOG.error("Kare kopyalanamadi", e);
        } finally {
            img.close();
            long dt = System.nanoTime() - t;
            cbAccumNs += dt;
            emaCbMs = emaCbMs * 0.8 + (dt / 1e6) * 0.2;
        }
    }

    private static long pixelPointer(NativeImage img, int w, int h) throws Exception {
        long expected = (long) w * h * 4;
        for (Field f : NativeImage.class.getDeclaredFields()) {
            if (f.getType() == long.class && !Modifier.isStatic(f.getModifiers())) {
                f.setAccessible(true);
                long v = f.getLong(img);
                if (v != 0 && v != expected) return v;
            }
        }
        return 0;
    }

    // ------------------------------------------------------------------ kodlama

    private static byte[] encode(Frame f, int tw, int th, int[] xmap, ThreadLocal<Scratch> tl,
                                 ConcurrentLinkedQueue<Scratch> all) {
        try {
            dbg("enc", "JPEG kodlama basliyor " + tw + "x" + th);
            Scratch s = tl.get();
            if (s == null) {
                s = new Scratch();
                tl.set(s);
                all.add(s);
            }
            ByteBuffer enc;
            if (f.w() == tw && f.h() == th) {
                enc = f.buf();
            } else {
                if (s.scaled == null || s.scaled.capacity() != tw * th * 4) {
                    if (s.scaled != null) MemoryUtil.memFree(s.scaled);
                    s.scaled = MemoryUtil.memAlloc(tw * th * 4);
                }
                IntBuffer src = f.buf().asIntBuffer();
                IntBuffer dst = s.scaled.asIntBuffer();
                int fw = f.w();
                int fh = f.h();
                for (int y = 0; y < th; y++) {
                    int rowSrc = (int) ((long) y * fh / th) * fw;
                    int rowDst = y * tw;
                    for (int x = 0; x < tw; x++) {
                        dst.put(rowDst + x, src.get(rowSrc + xmap[x]));
                    }
                }
                enc = s.scaled;
            }
            s.baos.reset();
            STBImageWrite.stbi_write_jpg_to_func(s.cb, 0L, tw, th, 4, enc, QUALITY);
            dbg("encdone", "JPEG hazir: " + s.baos.size() + " bayt");
            return s.baos.toByteArray();
        } finally {
            giveBuffer(f.buf());
        }
    }

    private static void writePending(AviWriter avi, Pending p) throws Exception {
        byte[] jpeg = p.future().get();
        for (int k = 0; k < p.copies(); k++) avi.addFrame(jpeg, jpeg.length);
        if (avi.length() > 1_900_000_000L) {
            ReplayMobileClient.LOG.warn("Dosya boyutu siniri doldu, kayit durduruluyor");
            recording = false;
        }
    }

    private static void work(Path out, boolean audio) {
        AviWriter avi = null;
        int tw = 0;
        int th = 0;
        int written = 0;
        long t0 = 0;
        int[] xmap = null;
        int xmapW = -1;
        final int fps = captureFps;

        final int threads = fps <= 10 ? 1 : Math.max(1, Math.min(2, Runtime.getRuntime().availableProcessors() / 4));
        final ThreadLocal<Scratch> tl = new ThreadLocal<>();
        final ConcurrentLinkedQueue<Scratch> all = new ConcurrentLinkedQueue<>();
        final ExecutorService encoders = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "replaymobile-encode");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
        });
        final ArrayDeque<Pending> pending = new ArrayDeque<>();

        try {
            while (true) {
                Frame f = queue.poll(60, TimeUnit.MILLISECONDS);
                if (avi != null && audio) GameAudio.drain(avi);
                while (avi != null && !pending.isEmpty() && pending.peekFirst().future().isDone()) {
                    writePending(avi, pending.pollFirst());
                }
                if (f == null) {
                    if (!recording && queue.isEmpty()) break;
                    continue;
                }
                if (t0 == 0) t0 = f.ns();
                int due = (int) ((f.ns() - t0) * fps / 1_000_000_000L) + 1;
                int copies = due - written;
                if (copies <= 0) {
                    giveBuffer(f.buf());
                    continue;
                }
                if (copies > 60) copies = 60;

                if (avi == null) {
                    th = Math.min(targetHeight, f.h());
                    tw = (int) Math.round(f.w() * (double) th / f.h());
                    tw &= ~1;
                    th &= ~1;
                    avi = new AviWriter(out, tw, th, audio);
                }
                if (xmap == null || xmapW != f.w()) {
                    xmap = new int[tw];
                    for (int x = 0; x < tw; x++) xmap[x] = (int) ((long) x * f.w() / tw);
                    xmapW = f.w();
                }
                final Frame ff = f;
                final int ftw = tw;
                final int fth = th;
                final int[] fx = xmap;
                Future<byte[]> fut = encoders.submit(() -> encode(ff, ftw, fth, fx, tl, all));
                pending.addLast(new Pending(fut, copies));
                written += copies;

                while (pending.size() > threads + 1) {
                    writePending(avi, pending.pollFirst());
                }
            }
            while (avi != null && !pending.isEmpty()) {
                writePending(avi, pending.pollFirst());
            }
        } catch (Throwable t) {
            recording = false;
            ReplayMobileClient.LOG.error("Ekran kaydi hatasi", t);
        } finally {
            encoders.shutdown();
            try {
                encoders.awaitTermination(15, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
            }
            for (Scratch s : all) {
                try {
                    s.cb.free();
                } catch (Throwable ignored) {
                }
                if (s.scaled != null) MemoryUtil.memFree(s.scaled);
            }
            Frame rest;
            while (queue != null && (rest = queue.poll()) != null) MemoryUtil.memFree(rest.buf());
            ByteBuffer pb;
            while ((pb = pool.poll()) != null) MemoryUtil.memFree(pb);
            GameAudio.finish();
            if (avi != null) {
                try {
                    if (audio) GameAudio.drain(avi);
                    avi.close(fps);
                    ReplayMobileClient.LOG.info("Ekran kaydi bitti: {} ({} kare)", out, written);
                } catch (Throwable t) {
                    ReplayMobileClient.LOG.error("AVI kapatilamadi", t);
                }
            }
        }
    }

    private ScreenRecorder() {}
}
