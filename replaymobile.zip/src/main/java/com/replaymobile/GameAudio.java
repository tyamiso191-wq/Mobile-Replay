package com.replaymobile;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.sound.OggAudioStream;
import net.minecraft.client.sound.Sound;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundInstanceListener;
import net.minecraft.entity.Entity;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALC11;
import org.lwjgl.system.MemoryUtil;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import javax.sound.sampled.AudioFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Oyun seslerini (SoundInstanceListener ile yakalanan olaylardan) ve mikrofonu kendi
 * karistiricisiyla 44100 Hz stereo PCM'e cevirir. Mesafe ve yon hesabi yaklasiktir.
 */
public final class GameAudio {
    static final int SR = 44100;

    private record Decoded(short[] pcm, int ch, int rate) {
        int frames() {
            return pcm.length / ch;
        }
    }

    private static final class Voice {
        SoundInstance inst;
        Future<Decoded> future;
        Decoded data;
        boolean failed;
        long startNs;
        double pos = -1;
        volatile boolean dead;
        int age;
        float range = 16f;
        volatile float vol = 1f;
        volatile float pitch = 1f;
        volatile double x, y, z;
        boolean relative;
        boolean spatial;
        boolean loop;
        float lastL = -1, lastR = -1;
    }

    private static volatile boolean running = false;
    private static boolean registered = false;
    private static Thread mixer;
    private static volatile double lx, ly, lz, lyaw;

    private static final ConcurrentLinkedQueue<byte[]> blocks = new ConcurrentLinkedQueue<>();
    private static final CopyOnWriteArrayList<Voice> voices = new CopyOnWriteArrayList<>();
    private static final ExecutorService decoder = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "replaymobile-decode");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY);
        return t;
    });
    private static final Map<String, Decoded> cache = new LinkedHashMap<>(16, 0.75f, true);
    private static long cacheBytes = 0;

    private static long micDev = 0;
    private static boolean micTried = false;
    private static float[] micBuf = new float[SR * 2];
    private static int micLen = 0;

    public static boolean isRunning() {
        return running;
    }

    public static boolean wanted() {
        return Config.recordGameAudio || Config.recordMic;
    }

    // ------------------------------------------------------------------ baslat / bitir

    public static synchronized void begin() {
        if (running || !wanted()) return;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (Config.recordGameAudio) ensureListener(mc);
            blocks.clear();
            voices.clear();
            micLen = 0;
            micTried = false;
            if (Config.recordMic) {
                micTried = true;
                micOpen();
            }
            running = true;
            mixer = new Thread(GameAudio::mixLoop, "replaymobile-mixer");
            mixer.setDaemon(true);
            mixer.setPriority(Thread.NORM_PRIORITY - 1);
            mixer.start();
        } catch (Throwable t) {
            running = false;
            ReplayMobileClient.LOG.error("Ses baslatilamadi", t);
        }
    }

    public static synchronized void finish() {
        if (!running && mixer == null) return;
        running = false;
        if (mixer != null) {
            try {
                mixer.join(3000);
            } catch (InterruptedException ignored) {
            }
            mixer = null;
        }
        micClose();
        voices.clear();
    }

    public static void drain(AviWriter avi) {
        byte[] b;
        while ((b = blocks.poll()) != null) {
            try {
                avi.addAudio(b);
            } catch (Throwable t) {
                ReplayMobileClient.LOG.error("Ses yazilamadi", t);
                return;
            }
        }
    }

    // ------------------------------------------------------------------ olay yakalama

    private static void ensureListener(MinecraftClient mc) {
        if (registered) return;
        InvocationHandler h = (proxy, method, args) -> {
            if (method.getDeclaringClass() == Object.class) {
                return switch (method.getName()) {
                    case "hashCode" -> System.identityHashCode(proxy);
                    case "equals" -> proxy == args[0];
                    default -> "ReplayMobileListener";
                };
            }
            try {
                onPlayed(args);
            } catch (Throwable t) {
                ReplayMobileClient.LOG.warn("Ses olayi islenemedi: {}", t.toString());
            }
            return null;
        };
        SoundInstanceListener listener = (SoundInstanceListener) Proxy.newProxyInstance(
                SoundInstanceListener.class.getClassLoader(), new Class<?>[] {SoundInstanceListener.class}, h);
        mc.getSoundManager().registerListener(listener);
        registered = true;
    }

    private static void onPlayed(Object[] args) {
        if (!running || !Config.recordGameAudio || args == null || args.length == 0) return;
        if (!(args[0] instanceof SoundInstance si)) return;
        Sound snd = si.getSound();
        if (snd == null) return;
        ScreenRecorder.dbg("snd", "ses olayi yakalandi");
        Voice v = new Voice();
        v.inst = si;
        v.startNs = System.nanoTime();
        if (args.length > 2 && args[2] instanceof Float r) v.range = Math.max(1f, r);
        v.relative = si.isRelative();
        v.spatial = !v.relative && si.getAttenuationType() == SoundInstance.AttenuationType.LINEAR;
        v.loop = si.isRepeatable();
        refresh(v, MinecraftClient.getInstance());
        v.future = decoder.submit(() -> decode(snd));
        voices.add(v);
    }

    private static void refresh(Voice v, MinecraftClient mc) {
        SoundInstance si = v.inst;
        GameOptions o = mc.options;
        SoundCategory cat = si.getCategory();
        float catVol = cat == SoundCategory.MASTER ? 1f : o.getSoundVolume(cat);
        float vol = si.getVolume() * catVol * o.getSoundVolume(SoundCategory.MASTER);
        v.vol = Math.max(0f, Math.min(1f, vol));
        v.pitch = Math.max(0.5f, Math.min(2f, si.getPitch()));
        v.x = si.getX();
        v.y = si.getY();
        v.z = si.getZ();
    }

    /** Her oyun tikinde cagrilir: dinleyici konumu, ses seviyesi/konumu guncelleme, biten sesleri temizleme. */
    public static void onTick(MinecraftClient mc) {
        if (!running) return;
        try {
            Entity e = mc.getCameraEntity();
            if (e != null) {
                lx = e.getX();
                ly = e.getEyeY();
                lz = e.getZ();
                lyaw = Math.toRadians(e.getYaw());
            }
            for (Voice v : voices) {
                v.age++;
                if (v.dead) continue;
                if (v.age > 2 && !mc.getSoundManager().isPlaying(v.inst)) {
                    v.dead = true;
                    continue;
                }
                refresh(v, mc);
            }
        } catch (Throwable t) {
            ReplayMobileClient.LOG.warn("Ses guncellenemedi: {}", t.toString());
        }
    }

    // ------------------------------------------------------------------ OGG cozme

    private static Decoded decode(Sound snd) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            ResourceManager rm = mc.getResourceManager();
            List<Identifier> cands = new ArrayList<>();
            for (Method m : Sound.class.getDeclaredMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType() == Identifier.class) {
                    m.setAccessible(true);
                    Object o = m.invoke(snd);
                    if (o instanceof Identifier id && !cands.contains(id)) cands.add(id);
                }
            }
            String key = cands.toString();
            synchronized (cache) {
                Decoded c = cache.get(key);
                if (c != null) return c;
            }
            for (Identifier id : cands) {
                List<Identifier> variants = new ArrayList<>();
                variants.add(id);
                if (!id.getPath().endsWith(".ogg")) {
                    variants.add(Identifier.of(id.getNamespace(), "sounds/" + id.getPath() + ".ogg"));
                }
                for (Identifier vid : variants) {
                    Optional<Resource> res = rm.getResource(vid);
                    if (res.isEmpty()) continue;
                    byte[] bytes;
                    try (InputStream in = res.get().getInputStream()) {
                        bytes = in.readAllBytes();
                    }
                    ScreenRecorder.dbg("dec", "ses cozuluyor (" + bytes.length + " bayt)");
                    Decoded d = decodeOgg(bytes);
                    ScreenRecorder.dbg("decdone", "ses cozuldu: " + (d != null));
                    if (d != null) {
                        long size = (long) d.pcm().length * 2;
                        if (size < 8L * 1024 * 1024) {
                            synchronized (cache) {
                                cache.put(key, d);
                                cacheBytes += size;
                                Iterator<Map.Entry<String, Decoded>> it = cache.entrySet().iterator();
                                while (cacheBytes > 48L * 1024 * 1024 && it.hasNext()) {
                                    Map.Entry<String, Decoded> en = it.next();
                                    cacheBytes -= (long) en.getValue().pcm().length * 2;
                                    it.remove();
                                }
                            }
                        }
                        return d;
                    }
                }
            }
        } catch (Throwable t) {
            ReplayMobileClient.LOG.warn("Ses cozulemedi: {}", t.toString());
        }
        return null;
    }

    private static Decoded decodeOgg(byte[] bytes) throws Exception {
        try (OggAudioStream stream = new OggAudioStream(new ByteArrayInputStream(bytes))) {
            AudioFormat fmt = stream.getFormat();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(Math.max(4096, bytes.length * 6));
            while (true) {
                ByteBuffer chunk = stream.read(65536);
                if (chunk == null || !chunk.hasRemaining()) break;
                byte[] tmp = new byte[chunk.remaining()];
                chunk.get(tmp);
                bo.write(tmp);
            }
            byte[] raw = bo.toByteArray();
            if (raw.length < 4 || fmt.getChannels() < 1) return null;
            short[] arr = new short[raw.length / 2];
            ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(arr);
            return new Decoded(arr, fmt.getChannels(), Math.round(fmt.getSampleRate()));
        }
    }

    // ------------------------------------------------------------------ mikrofon

    private static void micOpen() {
        try {
            micDev = ALC11.alcCaptureOpenDevice((CharSequence) null, SR, AL10.AL_FORMAT_MONO16, SR);
            if (micDev != 0) {
                ALC11.alcCaptureStart(micDev);
                ReplayMobileClient.LOG.info("Mikrofon acildi");
            } else {
                ReplayMobileClient.LOG.warn("Mikrofon acilamadi (izin veya cihaz yok)");
            }
        } catch (Throwable t) {
            micDev = 0;
            ReplayMobileClient.LOG.warn("Mikrofon desteklenmiyor: {}", t.toString());
        }
    }

    private static void micClose() {
        if (micDev == 0) return;
        try {
            ALC11.alcCaptureStop(micDev);
            ALC11.alcCaptureCloseDevice(micDev);
        } catch (Throwable ignored) {
        }
        micDev = 0;
    }

    /** Mikrofonu acip kapatir; kayit sirasinda da aninda etkili olur. */
    public static void toggleMic() {
        Config.recordMic = !Config.recordMic;
        Config.save();
        micTried = false;
        micLen = 0;
    }

    private static void micPoll() {
        if (micDev == 0) {
            if (!Config.recordMic || micTried) return;
            micTried = true;
            micOpen();
            if (micDev == 0) return;
        }
        try {
            int avail = ALC10.alcGetInteger(micDev, ALC11.ALC_CAPTURE_SAMPLES);
            if (avail <= 0) return;
            ShortBuffer sb = MemoryUtil.memAllocShort(avail);
            try {
                ALC11.alcCaptureSamples(micDev, sb, avail);
                if (!Config.recordMic) {
                    micLen = 0;
                    return;
                }
                if (micLen + avail > micBuf.length) {
                    int drop = micLen + avail - micBuf.length;
                    if (drop >= micLen) {
                        micLen = 0;
                    } else {
                        System.arraycopy(micBuf, drop, micBuf, 0, micLen - drop);
                        micLen -= drop;
                    }
                }
                int n = Math.min(avail, micBuf.length - micLen);
                for (int i = 0; i < n; i++) micBuf[micLen + i] = sb.get(i) / 32768f;
                micLen += n;
            } finally {
                MemoryUtil.memFree(sb);
            }
        } catch (Throwable t) {
            ReplayMobileClient.LOG.warn("Mikrofon okunamadi: {}", t.toString());
            micDev = 0;
        }
    }

    // ------------------------------------------------------------------ karistirici

    private static void mixLoop() {
        try {
            while (running && ScreenRecorder.firstNs() == 0) Thread.sleep(5);
            long startNs = ScreenRecorder.firstNs();
            if (startNs == 0) return;
            long done = 0;
            boolean last = false;
            while (true) {
                boolean stopping = !running;
                long target = (System.nanoTime() - startNs) * SR / 1_000_000_000L;
                int n = (int) Math.min(target - done, SR / 4);
                if (n < 1024 && !stopping) {
                    Thread.sleep(8);
                    continue;
                }
                if (n > 0) {
                    micPoll();
                    float[] mix = new float[n * 2];
                    mixVoices(mix, n);
                    mixMic(mix, n);
                    blocks.add(toPcm(mix, n));
                    done += n;
                }
                if (stopping) {
                    if (last || n <= 0) break;
                    last = true;
                }
            }
        } catch (Throwable t) {
            ReplayMobileClient.LOG.error("Ses karistirici hatasi", t);
        }
    }

    private static void mixMic(float[] mix, int n) {
        if (micLen <= 0) return;
        int take = Math.min(n, micLen);
        for (int i = 0; i < take; i++) {
            mix[2 * i] += micBuf[i];
            mix[2 * i + 1] += micBuf[i];
        }
        System.arraycopy(micBuf, take, micBuf, 0, micLen - take);
        micLen -= take;
    }

    private static void mixVoices(float[] mix, int n) {
        final float k = 1f / 32768f;
        final double lxs = lx, lys = ly, lzs = lz, yaw = lyaw;
        for (Voice v : voices) {
            if (v.dead) {
                voices.remove(v);
                continue;
            }
            if (v.data == null) {
                if (v.failed) {
                    voices.remove(v);
                    continue;
                }
                if (v.future != null && v.future.isDone()) {
                    try {
                        v.data = v.future.get();
                    } catch (Throwable t) {
                        v.data = null;
                    }
                    if (v.data == null) {
                        v.failed = true;
                        continue;
                    }
                    double elapsed = (System.nanoTime() - v.startNs) / 1e9;
                    v.pos = elapsed * v.data.rate() * v.pitch;
                } else {
                    continue;
                }
            }
            Decoded d = v.data;
            float gl = v.vol * k;
            float gr = gl;
            if (v.spatial) {
                double dx = v.x - lxs, dy = v.y - lys, dz = v.z - lzs;
                double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                float dg = (float) Math.max(0.0, 1.0 - dist / v.range);
                gl *= dg;
                gr *= dg;
                if (d.ch() == 1 && dist > 0.01) {
                    double hx = dx, hz = dz;
                    double hl = Math.sqrt(hx * hx + hz * hz);
                    if (hl > 0.01) {
                        hx /= hl;
                        hz /= hl;
                        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
                        double pan = Math.max(-1.0, Math.min(1.0, hx * rx + hz * rz));
                        double ang = (pan + 1.0) * Math.PI / 4.0;
                        float pl = (float) Math.cos(ang) * 1.4142f;
                        float pr = (float) Math.sin(ang) * 1.4142f;
                        gl *= pl;
                        gr *= pr;
                    }
                }
            }
            if (v.lastL < 0) {
                v.lastL = gl;
                v.lastR = gr;
            }
            double step = d.rate() / (double) SR * v.pitch;
            int total = d.frames();
            for (int i = 0; i < n; i++) {
                if (v.pos >= total) {
                    if (v.loop) v.pos -= total;
                    else {
                        v.dead = true;
                        break;
                    }
                }
                int i0 = (int) v.pos;
                int i1 = i0 + 1 >= total ? (v.loop ? 0 : i0) : i0 + 1;
                float fr = (float) (v.pos - i0);
                float l, r;
                if (d.ch() == 1) {
                    float s = d.pcm()[i0] * (1f - fr) + d.pcm()[i1] * fr;
                    l = s;
                    r = s;
                } else {
                    int a = i0 * d.ch(), b = i1 * d.ch();
                    l = d.pcm()[a] * (1f - fr) + d.pcm()[b] * fr;
                    r = d.pcm()[a + 1] * (1f - fr) + d.pcm()[b + 1] * fr;
                }
                float t = (i + 1f) / n;
                float cl = v.lastL + (gl - v.lastL) * t;
                float cr = v.lastR + (gr - v.lastR) * t;
                mix[2 * i] += l * cl;
                mix[2 * i + 1] += r * cr;
                v.pos += step;
            }
            v.lastL = gl;
            v.lastR = gr;
        }
    }

    private static byte[] toPcm(float[] mix, int n) {
        byte[] out = new byte[n * 4];
        for (int i = 0; i < n * 2; i++) {
            float x = mix[i];
            float ax = Math.abs(x);
            if (ax > 0.9f) {
                float y = 0.9f + 0.1f * (float) Math.tanh((ax - 0.9f) / 0.1f);
                x = Math.signum(x) * y;
            }
            int s = Math.round(x * 32767f);
            if (s > 32767) s = 32767;
            if (s < -32768) s = -32768;
            out[2 * i] = (byte) s;
            out[2 * i + 1] = (byte) (s >> 8);
        }
        return out;
    }

    private GameAudio() {}
}
