package com.replaymobile;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextWidget;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class ReplayListScreen extends Screen {
    private static final double[] SPEEDS = {0.5, 1.0, 2.0, 4.0};

    private final Screen parent;
    private TextWidget status;

    public ReplayListScreen(Screen parent) {
        super(Text.literal("Replay"));
        this.parent = parent;
    }

    private static Text autoLabel() {
        return Text.literal("Oturum yakalama: " + (Config.autoRecord ? "AÇIK" : "KAPALI"));
    }

    private static Text speedLabel() {
        return Text.literal("Oynatma hızı: " + Playback.speed + "x");
    }

    private static List<Path> listFiles() {
        List<Path> result = new ArrayList<>();
        Path dir = Recorder.recordingsDir();
        if (!Files.isDirectory(dir)) return result;
        try (Stream<Path> s = Files.list(dir)) {
            s.filter(p -> p.getFileName().toString().endsWith(".replay")).forEach(result::add);
        } catch (IOException ignored) {
        }
        result.sort(Comparator.comparingLong((Path p) -> p.toFile().lastModified()).reversed());
        return result;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        TextWidget title = new TextWidget(Text.literal("Replay kayıtları"), this.textRenderer);
        title.setPosition(cx - title.getWidth() / 2, 8);
        this.addDrawableChild(title);

        this.addDrawableChild(ButtonWidget.builder(autoLabel(), b -> {
            Config.autoRecord = !Config.autoRecord;
            Config.save();
            b.setMessage(autoLabel());
        }).dimensions(cx - 150, 24, 148, 20).build());

        this.addDrawableChild(ButtonWidget.builder(speedLabel(), b -> {
            int idx = 0;
            for (int i = 0; i < SPEEDS.length; i++) {
                if (SPEEDS[i] == Playback.speed) idx = i;
            }
            Playback.speed = SPEEDS[(idx + 1) % SPEEDS.length];
            b.setMessage(speedLabel());
        }).dimensions(cx + 2, 24, 148, 20).build());

        List<Path> files = listFiles();
        int y = 52;
        for (int i = 0; i < Math.min(files.size(), 6); i++) {
            Path p = files.get(i);
            long kb = Math.max(1, p.toFile().length() / 1024);
            String name = p.getFileName().toString();
            this.addDrawableChild(ButtonWidget.builder(Text.literal("▶ " + name + "  (" + kb + " KB)"), b ->
                    status.setMessage(Text.literal(Playback.start(p, this)))
            ).dimensions(cx - 150, y, 300, 20).build());
            y += 24;
        }
        if (files.isEmpty()) {
            TextWidget empty = new TextWidget(Text.literal("Henüz kayıt yok."), this.textRenderer);
            empty.setPosition(cx - empty.getWidth() / 2, 56);
            this.addDrawableChild(empty);
        }

        this.status = new TextWidget(cx - 150, this.height - 50, 300, 12, Text.literal(""), this.textRenderer).alignCenter();
        this.addDrawableChild(this.status);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Geri"), b -> this.close())
                .dimensions(cx - 100, this.height - 28, 200, 20).build());
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(this.parent);
    }
}
