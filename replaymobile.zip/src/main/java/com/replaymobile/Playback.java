package com.replaymobile;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Kaydi oynatir: yerel (127.0.0.1) sahte bir sunucu acar, oyunun kendi istemcisi ona baglanir
 * ve kayitli paketler zamanlamasina gore ona gonderilir. Saf Java, native yok.
 */
public final class Playback {
    public static volatile double speed = 1.0;

    private static volatile boolean active = false;
    private static volatile boolean stopRequested = false;
    private static ServerSocket server;
    private static Socket client;

    public static boolean isActive() {
        return active;
    }

    public static void onDisconnect() {
        if (active) stop();
    }

    public static synchronized void stop() {
        stopRequested = true;
        active = false;
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }
        try {
            if (client != null) client.close();
        } catch (IOException ignored) {
        }
    }

    /** Oynatmayi baslatir, kullaniciya gosterilecek durum mesajini dondurur. */
    public static synchronized String start(Path file, Screen parent) {
        if (active) stop();
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
            if (in.readInt() != Recorder.MAGIC) return "Geçersiz dosya.";
            int ver = in.readInt();
            if (ver != Recorder.VERSION) return "Eski kayıt biçimi (v" + ver + "), oynatılamaz.";
        } catch (IOException e) {
            return "Dosya okunamadı.";
        }
        boolean hasMark = false;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
            in.readInt();
            in.readInt();
            in.readUTF();
            in.readLong();
            while (true) {
                int st = in.read();
                if (st < 0) break;
                in.readLong();
                int len = in.readInt();
                if (st == 2) {
                    hasMark = true;
                    break;
                }
                in.skipNBytes(len);
            }
        } catch (IOException ignored) {
        }
        final boolean marks = hasMark;
        try {
            server = new ServerSocket(0, 1, InetAddress.getLoopbackAddress());
            server.setSoTimeout(60000);
        } catch (IOException e) {
            return "Yerel sunucu açılamadı.";
        }
        int port = server.getLocalPort();
        active = true;
        stopRequested = false;
        final ServerSocket ss = server;
        Thread t = new Thread(() -> serve(file, ss, marks), "replaymobile-server");
        t.setDaemon(true);
        t.start();

        String addr = "127.0.0.1:" + port;
        if (tryConnect(parent, addr)) return "Bağlanılıyor...";
        return "Otomatik bağlanılamadı. Çok oyunculu > Doğrudan bağlan: " + addr;
    }

    // ---------------------------------------------------------------- baglanti

    private static boolean tryConnect(Screen parent, String addr) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            for (Method m : ConnectScreen.class.getDeclaredMethods()) {
                if (!Modifier.isStatic(m.getModifiers())) continue;
                Class<?>[] pt = m.getParameterTypes();
                if (pt.length >= 4 && pt[0] == Screen.class && pt[1] == MinecraftClient.class
                        && pt[2] == ServerAddress.class && pt[3] == ServerInfo.class) {
                    Object[] args = new Object[pt.length];
                    args[0] = parent;
                    args[1] = mc;
                    args[2] = ServerAddress.parse(addr);
                    args[3] = makeInfo(addr);
                    for (int i = 4; i < pt.length; i++) {
                        args[i] = pt[i] == boolean.class ? Boolean.FALSE : null;
                    }
                    if (args[3] == null) return false;
                    m.setAccessible(true);
                    m.invoke(null, args);
                    return true;
                }
            }
        } catch (Throwable t) {
            ReplayMobileClient.LOG.error("Otomatik baglanti basarisiz", t);
        }
        return false;
    }

    private static Object makeInfo(String addr) throws Exception {
        for (Constructor<?> c : ServerInfo.class.getConstructors()) {
            Class<?>[] pt = c.getParameterTypes();
            if (pt.length == 3 && pt[0] == String.class && pt[1] == String.class && pt[2].isEnum()) {
                Object[] consts = pt[2].getEnumConstants();
                Object pick = consts[consts.length - 1];
                for (Object o : consts) {
                    if (o.toString().equalsIgnoreCase("OTHER")) pick = o;
                }
                return c.newInstance("Replay", addr, pick);
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- sahte sunucu

    private static void serve(Path file, ServerSocket ss, boolean hasMark) {
        Socket s = null;
        try {
            InputStream in;
            OutputStream out;
            while (true) {
                s = ss.accept();
                s.setTcpNoDelay(true);
                in = new BufferedInputStream(s.getInputStream());
                out = new BufferedOutputStream(s.getOutputStream());
                byte[] hs = readFrame(in);
                if (parseIntent(hs) >= 2) break;
                s.close();
            }
            client = s;

            // Login Start: ad + uuid
            byte[] ls = readFrame(in);
            DataInputStream d = new DataInputStream(new ByteArrayInputStream(ls));
            readVarInt(d);
            String name = readString(d);
            byte[] uuid = new byte[16];
            d.readFully(uuid);

            // Login Finished
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            writeVarInt(bo, 0x02);
            bo.write(uuid);
            writeString(bo, name);
            writeVarInt(bo, 0);
            sendFrame(out, bo.toByteArray());
            out.flush();

            final CountDownLatch latchLogin = new CountDownLatch(1);
            final CountDownLatch latchConfig = new CountDownLatch(1);
            final InputStream fin = in;
            Thread reader = new Thread(() -> {
                int count = 0;
                try {
                    while (true) {
                        byte[] f = readFrame(fin);
                        int id = readVarInt(new ByteArrayInputStream(f));
                        if (id == 3 && count < 2) {
                            count++;
                            if (count == 1) latchLogin.countDown();
                            else latchConfig.countDown();
                        }
                    }
                } catch (Throwable ignored) {
                } finally {
                    stopRequested = true;
                    latchLogin.countDown();
                    latchConfig.countDown();
                }
            }, "replaymobile-reader");
            reader.setDaemon(true);
            reader.start();

            if (!latchLogin.await(30, TimeUnit.SECONDS) || stopRequested) return;

            try (DataInputStream rec = new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
                rec.readInt();
                rec.readInt();
                rec.readUTF();
                rec.readLong();

                boolean playStarted = false;
                boolean timed = false;
                boolean segment = false;
                long t0 = 0;
                long wall0 = 0;
                while (!stopRequested) {
                    int st = rec.read();
                    if (st < 0) break;
                    long t = rec.readLong();
                    int len = rec.readInt();
                    byte[] data = new byte[len];
                    rec.readFully(data);

                    if (st == 2) {
                        out.flush();
                        timed = true;
                        segment = true;
                        t0 = t;
                        wall0 = System.nanoTime();
                        continue;
                    }
                    if (st == 3) {
                        if (segment) break;
                        continue;
                    }
                    if (st == 1 && !playStarted) {
                        out.flush();
                        if (!latchConfig.await(30, TimeUnit.SECONDS) || stopRequested) return;
                        playStarted = true;
                        if (!hasMark) {
                            timed = true;
                            t0 = t;
                            wall0 = System.nanoTime();
                        }
                    }
                    if (st == 1 && timed) {
                        long target = wall0 + (long) ((t - t0) * 1_000_000.0 / speed);
                        long wait;
                        while ((wait = target - System.nanoTime()) > 0 && !stopRequested) {
                            out.flush();
                            Thread.sleep(Math.min(20, Math.max(1, wait / 1_000_000)));
                        }
                    }
                    sendFrame(out, data);
                    if (st == 1 && timed) out.flush();
                }
            } catch (EOFException ignored) {
            }
            out.flush();
            Thread.sleep(1500);
        } catch (Throwable t) {
            if (!stopRequested) ReplayMobileClient.LOG.warn("Oynatma sunucusu durdu: {}", t.toString());
        } finally {
            try {
                if (s != null) s.close();
            } catch (IOException ignored) {
            }
            try {
                ss.close();
            } catch (IOException ignored) {
            }
            active = false;
        }
    }

    // ---------------------------------------------------------------- protokol yardimcilari

    private static int parseIntent(byte[] hs) throws IOException {
        DataInputStream d = new DataInputStream(new ByteArrayInputStream(hs));
        readVarInt(d);
        readVarInt(d);
        int hostLen = readVarInt(d);
        d.skipBytes(hostLen);
        d.skipBytes(2);
        return readVarInt(d);
    }

    private static byte[] readFrame(InputStream in) throws IOException {
        int len = readVarInt(in);
        if (len < 0 || len > (1 << 24)) throw new IOException("Gecersiz uzunluk");
        byte[] b = new byte[len];
        int off = 0;
        while (off < len) {
            int r = in.read(b, off, len - off);
            if (r < 0) throw new EOFException();
            off += r;
        }
        return b;
    }

    private static void sendFrame(OutputStream out, byte[] data) throws IOException {
        writeVarInt(out, data.length);
        out.write(data);
    }

    private static int readVarInt(InputStream in) throws IOException {
        int v = 0;
        int pos = 0;
        while (true) {
            int b = in.read();
            if (b < 0) throw new EOFException();
            v |= (b & 0x7F) << pos;
            if ((b & 0x80) == 0) return v;
            pos += 7;
            if (pos >= 35) throw new IOException("VarInt cok buyuk");
        }
    }

    private static void writeVarInt(OutputStream out, int value) throws IOException {
        while ((value & ~0x7F) != 0) {
            out.write((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        out.write(value);
    }

    private static String readString(InputStream in) throws IOException {
        int len = readVarInt(in);
        byte[] b = in.readNBytes(len);
        return new String(b, StandardCharsets.UTF_8);
    }

    private static void writeString(OutputStream out, String s) throws IOException {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        writeVarInt(out, b.length);
        out.write(b);
    }

    private Playback() {}
}
