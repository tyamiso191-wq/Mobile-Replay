package com.replaymobile;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Saf Java MJPEG/AVI yazici (native yok). Kareler hazir JPEG olarak verilir. */
final class AviWriter {
    private final RandomAccessFile f;
    private long avihPos;
    private long strhPos;
    private long moviSizePos;
    private long moviTagPos;
    private final List<int[]> index = new ArrayList<>();
    private int maxChunk = 0;

    AviWriter(Path path, int w, int h) throws IOException {
        f = new RandomAccessFile(path.toFile(), "rw");
        f.setLength(0);
        tag("RIFF"); le32(0); tag("AVI ");
        tag("LIST"); le32(192); tag("hdrl");
        tag("avih"); le32(56);
        avihPos = f.getFilePointer();
        le32(50000); le32(0); le32(0); le32(0x10); le32(0); le32(0); le32(1); le32(0); le32(w); le32(h);
        le32(0); le32(0); le32(0); le32(0);
        tag("LIST"); le32(116); tag("strl");
        tag("strh"); le32(56);
        strhPos = f.getFilePointer();
        tag("vids"); tag("MJPG");
        le32(0); le32(0); le32(0); le32(1000); le32(20000); le32(0); le32(0); le32(0); le32(-1); le32(0);
        le16(0); le16(0); le16(w); le16(h);
        tag("strf"); le32(40);
        le32(40); le32(w); le32(h); le16(1); le16(24); tag("MJPG"); le32(w * h * 3);
        le32(0); le32(0); le32(0); le32(0);
        tag("LIST");
        moviSizePos = f.getFilePointer();
        le32(0);
        moviTagPos = f.getFilePointer();
        tag("movi");
    }

    void addFrame(byte[] jpeg, int len) throws IOException {
        long pos = f.getFilePointer();
        index.add(new int[] {(int) (pos - moviTagPos), len});
        tag("00dc");
        le32(len);
        f.write(jpeg, 0, len);
        if ((len & 1) == 1) f.write(0);
        if (len > maxChunk) maxChunk = len;
    }

    long length() throws IOException {
        return f.getFilePointer();
    }

    int frameCount() {
        return index.size();
    }

    void close(double fps) throws IOException {
        long moviEnd = f.getFilePointer();
        tag("idx1");
        le32(index.size() * 16);
        for (int[] e : index) {
            tag("00dc"); le32(0x10); le32(e[0]); le32(e[1]);
        }
        long end = f.getFilePointer();
        int frames = index.size();
        patch(4, (int) (end - 8));
        patch(moviSizePos, (int) (moviEnd - moviTagPos));
        patch(avihPos, (int) Math.round(1_000_000.0 / fps));
        patch(avihPos + 4, (int) (maxChunk * fps));
        patch(avihPos + 16, frames);
        patch(avihPos + 28, maxChunk);
        patch(strhPos + 20, 1000);
        patch(strhPos + 24, (int) Math.round(fps * 1000));
        patch(strhPos + 32, frames);
        patch(strhPos + 36, maxChunk);
        f.close();
    }

    private void patch(long pos, int v) throws IOException {
        f.seek(pos);
        le32(v);
    }

    private void tag(String s) throws IOException {
        f.write(s.getBytes(StandardCharsets.US_ASCII));
    }

    private void le32(int v) throws IOException {
        f.write(new byte[] {(byte) v, (byte) (v >> 8), (byte) (v >> 16), (byte) (v >> 24)});
    }

    private void le16(int v) throws IOException {
        f.write(new byte[] {(byte) v, (byte) (v >> 8)});
    }
}
