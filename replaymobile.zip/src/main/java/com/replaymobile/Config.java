package com.replaymobile;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    public static boolean autoRecord = true;
    public static boolean recordGameAudio = true;
    public static boolean recordMic = true;
    public static int recordFps = 20;
    public static int recordHeight = 1080;
    public static int perfMode = 1; // 0=oyun akici, 1=dengeli, 2=video akici

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("replaymobile.properties");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Properties props = new Properties();
                try (InputStream in = Files.newInputStream(p)) {
                    props.load(in);
                }
                autoRecord = Boolean.parseBoolean(props.getProperty("autoRecord", "true"));
                recordGameAudio = Boolean.parseBoolean(props.getProperty("recordGameAudio", "true"));
                recordMic = Boolean.parseBoolean(props.getProperty("recordMic", "true"));
                recordFps = Integer.parseInt(props.getProperty("recordFps", "20"));
                recordHeight = Integer.parseInt(props.getProperty("recordHeight", "1080"));
                perfMode = Integer.parseInt(props.getProperty("perfMode", "1"));
                if (Integer.parseInt(props.getProperty("cfgVer", "1")) < 3) {
                    recordFps = 20;
                    perfMode = 1;
                }
            }
        } catch (Exception e) {
            ReplayMobileClient.LOG.warn("Ayar okunamadi", e);
        }
    }

    public static void save() {
        try {
            Properties props = new Properties();
            props.setProperty("autoRecord", Boolean.toString(autoRecord));
            props.setProperty("recordGameAudio", Boolean.toString(recordGameAudio));
            props.setProperty("recordMic", Boolean.toString(recordMic));
            props.setProperty("recordFps", Integer.toString(recordFps));
            props.setProperty("recordHeight", Integer.toString(recordHeight));
            props.setProperty("perfMode", Integer.toString(perfMode));
            props.setProperty("cfgVer", "3");
            try (OutputStream out = Files.newOutputStream(path())) {
                props.store(out, "Replay Mobile");
            }
        } catch (Exception e) {
            ReplayMobileClient.LOG.warn("Ayar yazilamadi", e);
        }
    }

    private Config() {}
}
