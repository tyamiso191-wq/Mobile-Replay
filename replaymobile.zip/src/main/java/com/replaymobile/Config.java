package com.replaymobile;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    public static boolean autoRecord = true;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("replaymobile.properties");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Properties props = new Properties();
                try (InputStream in = Files.newInputStream(p)) {
                    props.load(in);
                }
                autoRecord = Boolean.parseBoolean(props.getProperty("autoRecord", "true"));
            }
        } catch (Exception e) {
            ReplayMobileClient.LOG.warn("Ayar okunamadi", e);
        }
    }

    public static void save() {
        try {
            Properties props = new Properties();
            props.setProperty("autoRecord", Boolean.toString(autoRecord));
            try (OutputStream out = Files.newOutputStream(path())) {
                props.store(out, "Replay Mobile");
            }
        } catch (Exception e) {
            ReplayMobileClient.LOG.warn("Ayar yazilamadi", e);
        }
    }

    private Config() {}
}
