package com.replaymobile;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/** R tusu: Replay menusunu acar. Tus atamasi Kontroller ekranindan degistirilebilir. */
public final class Keys {
    private static KeyBinding openKey;

    public static void register() {
        try {
            KeyBinding kb = create();
            if (kb == null) {
                ReplayMobileClient.LOG.warn("Tus atamasi olusturulamadi (surum farki)");
                return;
            }
            openKey = KeyBindingHelper.registerKeyBinding(kb);
        } catch (Throwable t) {
            ReplayMobileClient.LOG.warn("Tus kaydedilemedi: {}", t.toString());
        }
    }

    public static void onTick(MinecraftClient mc) {
        if (openKey == null) return;
        while (openKey.wasPressed()) {
            if (mc.currentScreen == null) {
                mc.setScreen(new ReplayListScreen(null));
            }
        }
    }

    private static KeyBinding create() throws Exception {
        for (Constructor<?> c : KeyBinding.class.getConstructors()) {
            Class<?>[] pt = c.getParameterTypes();
            if (pt.length < 4 || pt.length > 5) continue;
            if (pt[0] != String.class || pt[1] != InputUtil.Type.class || pt[2] != int.class) continue;
            Object cat;
            if (pt[3] == String.class) cat = "key.categories.replaymobile";
            else cat = makeCategory(pt[3]);
            if (cat == null) continue;
            if (pt.length == 4) {
                return (KeyBinding) c.newInstance("key.replaymobile.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, cat);
            }
            if (pt[4] == int.class) {
                return (KeyBinding) c.newInstance("key.replaymobile.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, cat, 0);
            }
        }
        return null;
    }

    private static Object makeCategory(Class<?> catType) throws Exception {
        for (Method m : catType.getMethods()) {
            Class<?>[] mp = m.getParameterTypes();
            if (Modifier.isStatic(m.getModifiers()) && mp.length == 1 && mp[0] == Identifier.class
                    && catType.isAssignableFrom(m.getReturnType())) {
                return m.invoke(null, Identifier.of("replaymobile", "main"));
            }
        }
        for (Field f : catType.getFields()) {
            if (Modifier.isStatic(f.getModifiers()) && f.getType() == catType) {
                return f.get(null);
            }
        }
        return null;
    }

    private Keys() {}
}
