package com.replaymobile;

import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelPipeline;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.ClientConnection;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Sunucudan gelen ham paketleri (config + play) .replay dosyasina yazar.
 * Dosya (v2): [int MAGIC][int 2][UTF mcSurum][long baslangicMs]
 * sonra tekrar eden: [byte durum 0=config 1=play][long gecenMs][int uzunluk][bayt...]
 */
public final class Recorder {
    public static final int MAGIC = 0x4D435250;
    public static final int VERSION = 2;

    private static final String HANDLER_NAME = "replaymobile_capture";
    private static final Object LOCK = new Object();

    private static volatile boolean recording = false;
    private static volatile boolean clip = false;
    private static int clipCount = 0;
    private static volatile int state = 0;
    private static Channel channel;
    private static DataOutputStream out;
    private static Path file;
    private static long startMs;

    /** Oturum yakalaniyor mu (dosya acik, paketler yaziliyor)? */
    public static boolean isCapturing() {
        return recording;
    }

    /** Kullanici "kayit"i baslatti mi (isaretli bolum acik mi)? */
    public static boolean isClipActive() {
        return clip;
    }

    public static Path recordingsDir() {
        return FabricLoader.getInstance().getGameDir().resolve("replay_recordings");
    }

    /** Config asamasi basladiginda cagrilir (ilk paketten once). */
    public static void onConfigInit(Object handler) {
        stop();
        if (Playback.isActive() || !Config.autoRecord) return;
        ClientConnection conn = findConnection(handler);
        if (conn == null) {
            ReplayMobileClient.LOG.warn("Baglanti nesnesi bulunamadi");
            return;
        }
        start(conn);
    }

    /** ESC dugmesi: kaydi baslatir / bitirir (dosyaya baslangic ve bitis isareti yazar). */
    public static void toggleClip() {
        if (!recording || state != 1) return;
        writeMark(clip ? 3 : 2);
        if (!clip) clipCount++;
        clip = !clip;
    }

    private static void writeMark(int st) {
        long t = System.currentTimeMillis() - startMs;
        synchronized (LOCK) {
            if (out == null) return;
            try {
                out.writeByte(st);
                out.writeLong(t);
                out.writeInt(0);
            } catch (Throwable e) {
                ReplayMobileClient.LOG.error("Isaret yazilamadi", e);
            }
        }
    }

    private static void start(ClientConnection conn) {
        try {
            channel = findChannel(conn);
            if (channel == null) {
                ReplayMobileClient.LOG.warn("Netty kanali bulunamadi");
                return;
            }
            ChannelPipeline pipeline = channel.pipeline();
            String anchor = null;
            for (String name : new String[] {"inbound_config", "decoder"}) {
                if (pipeline.get(name) != null) {
                    anchor = name;
                    break;
                }
            }
            if (anchor == null) {
                ReplayMobileClient.LOG.warn("Pipeline'da decoder bulunamadi: {}", pipeline.names());
                return;
            }

            Files.createDirectories(recordingsDir());
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            file = recordingsDir().resolve(stamp + ".replay");
            startMs = System.currentTimeMillis();
            state = 0;
            clip = false;
            clipCount = 0;

            synchronized (LOCK) {
                out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(file), 1 << 16));
                out.writeInt(MAGIC);
                out.writeInt(VERSION);
                out.writeUTF(mcVersion());
                out.writeLong(startMs);
            }

            if (pipeline.get(HANDLER_NAME) != null) pipeline.remove(HANDLER_NAME);
            pipeline.addBefore(anchor, HANDLER_NAME, new Capture());
            recording = true;
            ReplayMobileClient.LOG.info("Kayit basladi: {}", file);
        } catch (Throwable t) {
            ReplayMobileClient.LOG.error("Kayit baslatilamadi", t);
            closeFile();
        }
    }

    public static void stop() {
        boolean was = recording;
        if (was && clip) writeMark(3);
        clip = false;
        recording = false;
        try {
            if (channel != null && channel.pipeline().get(HANDLER_NAME) != null) {
                channel.pipeline().remove(HANDLER_NAME);
            }
        } catch (Throwable ignored) {
        }
        closeFile();
        if (was && file != null) {
            if (clipCount == 0) {
                try {
                    Files.deleteIfExists(file);
                } catch (Throwable ignored) {
                }
                ReplayMobileClient.LOG.info("Kayit baslatilmadigi icin gecici dosya silindi");
            } else {
                ReplayMobileClient.LOG.info("Kayit kaydedildi: {}", file);
            }
        }
        clipCount = 0;
        channel = null;
    }

    private static void closeFile() {
        synchronized (LOCK) {
            if (out != null) {
                try {
                    out.flush();
                    out.close();
                } catch (Throwable ignored) {
                }
                out = null;
            }
        }
    }

    private static void write(ByteBuf buf) {
        int len = buf.readableBytes();
        byte[] data = new byte[len];
        buf.getBytes(buf.readerIndex(), data);
        long t = System.currentTimeMillis() - startMs;
        int st = state;
        synchronized (LOCK) {
            if (out == null) return;
            try {
                out.writeByte(st);
                out.writeLong(t);
                out.writeInt(len);
                out.write(data);
            } catch (Throwable e) {
                recording = false;
                ReplayMobileClient.LOG.error("Yazma hatasi", e);
            }
        }
        // Config'teki FinishConfiguration paketi (id 3, govde yok) play asamasinin basladigini gosterir.
        if (st == 0 && len == 1 && data[0] == 3) {
            state = 1;
        }
    }

    private static ClientConnection findConnection(Object handler) {
        for (Class<?> c = handler.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (ClientConnection.class.isAssignableFrom(f.getType())) {
                    try {
                        f.setAccessible(true);
                        return (ClientConnection) f.get(handler);
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
        return null;
    }

    private static Channel findChannel(ClientConnection conn) throws Exception {
        for (Field f : ClientConnection.class.getDeclaredFields()) {
            if (Channel.class.isAssignableFrom(f.getType())) {
                f.setAccessible(true);
                return (Channel) f.get(conn);
            }
        }
        return null;
    }

    private static String mcVersion() {
        return FabricLoader.getInstance().getModContainer("minecraft")
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("unknown");
    }

    private static final class Capture extends ChannelInboundHandlerAdapter {
        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) {
            try {
                if (recording && msg instanceof ByteBuf buf) {
                    write(buf);
                }
            } catch (Throwable t) {
                ReplayMobileClient.LOG.error("Paket yakalama hatasi", t);
            }
            ctx.fireChannelRead(msg);
        }
    }

    private Recorder() {}
}
