package com.replaymobile;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReplayMobileClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("replaymobile");

    private static Text replayLabel() {
        if (Playback.isActive()) return Text.literal("1) Replay oynuyor");
        if (!Recorder.isCapturing()) return Text.literal("1) Replay kaydı: yakalama kapalı");
        if (Recorder.isClipActive()) return Text.literal("1) Replay kaydı: AÇIK (bitir)");
        return Text.literal("1) Replay kaydı: başlat");
    }

    private static Text screenLabel() {
        return Text.literal(ScreenRecorder.isRecording() ? "2) Ekran kaydı: AÇIK (bitir)" : "2) Ekran kaydı: başlat");
    }

    private static Text micLabel() {
        return Text.literal("3) Mikrofon: " + (Config.recordMic ? "AÇIK" : "KAPALI"));
    }

    @Override
    public void onInitializeClient() {
        Config.load();
        Keys.register();

        ClientConfigurationConnectionEvents.INIT.register((handler, client) -> Recorder.onConfigInit(handler));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            Recorder.stop();
            Playback.onDisconnect();
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Keys.onTick(client);
            GameAudio.onTick(client);
            ScreenRecorder.onTick(client);
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ScreenRecorder.stop();
            Recorder.stop();
            Playback.stop();
        });

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(replayLabel(), b -> {
                    Recorder.toggleClip();
                    b.setMessage(replayLabel());
                }).dimensions(5, 5, 175, 20).build());
                Screens.getButtons(screen).add(ButtonWidget.builder(screenLabel(), b -> {
                    ScreenRecorder.toggle();
                    b.setMessage(screenLabel());
                }).dimensions(5, 28, 175, 20).build());
                Screens.getButtons(screen).add(ButtonWidget.builder(micLabel(), b -> {
                    GameAudio.toggleMic();
                    b.setMessage(micLabel());
                }).dimensions(5, 51, 175, 20).build());
            } else if (screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Replay"), b ->
                        client.setScreen(new ReplayListScreen(screen))
                ).dimensions(5, 5, 100, 20).build());
                Screens.getButtons(screen).add(ButtonWidget.builder(screenLabel(), b -> {
                    ScreenRecorder.toggle();
                    b.setMessage(screenLabel());
                }).dimensions(5, 28, 175, 20).build());
                Screens.getButtons(screen).add(ButtonWidget.builder(micLabel(), b -> {
                    GameAudio.toggleMic();
                    b.setMessage(micLabel());
                }).dimensions(5, 51, 175, 20).build());
            }
        });
    }
}
