Replay Mobile 0.3.0
Minecraft 1.21.11, Fabric. Saf Java, native kutuphane yok.
Replay kayitlari : .minecraft/replay_recordings/*.replay
Ekran kayitlari  : .minecraft/screen_recordings/*.avi  (en fazla 1080p, MJPEG, sessiz)
