Replay Mobile 0.5.0
Minecraft 1.21.11, Fabric. Saf Java, native kutuphane yok.
Replay kayitlari : .minecraft/replay_recordings/*.replay
Ekran kayitlari  : .minecraft/screen_recordings/*.avi  (MJPEG + PCM ses)
Ekran kaydi oyunu yavaslatmamak icin yakalama hizini kendiliginden ayarlar (cozunurluk sabit kalir).
